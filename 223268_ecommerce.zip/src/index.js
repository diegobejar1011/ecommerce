import React from 'react'
import ReactDOM from 'react-dom/client'
import UserP from '../src/pages/UserP'
import './index.css'

const root= ReactDOM.createRoot(document.getElementById("root"));

root.render(<>
<UserP />
</>);